import * as React from 'react';

export const Footer: React.StatelessComponent<{}> = () => {
    return (
        <footer>
            <span>Copyright © PORTERS Corporation All Rights Reserved.</span>
        </footer>
    );
};

import * as React from 'react';

export const SearchBox: React.StatelessComponent<{}> = () => {
    return (
        <div className="search-box">
            <span>SearchBox</span>
        </div>
    );
};

import * as React from 'react';

export interface LinkButtonProps {
    className: string;
    title?: string;
    text?: string;
    url?: string;
    newTab?: boolean;
}

export const LinkButton: React.StatelessComponent<LinkButtonProps> = (props: LinkButtonProps) => {
    const { className, title, text, url, newTab } = props;
    return (
        <a 
            className={"header-icon " + className}
            title={title || ''}
            href={url || ''}
            target={newTab === true ? "_blank" : ""}>
                {text || ''}
        </a>
    );
};
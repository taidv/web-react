import * as React from 'react';
import { SearchBox, LinkButton } from '../common';
import { UserInfo, UserInfoProps } from './userInfo'
import { Action } from '../../actions';
import { Translate, SetActiveLanguageAction, TranslateFunction, getActiveLanguage } from 'react-localize-redux';



export interface HeaderProps {
    userInfo: {
        companyName: string;
        userName: string;
        translate: TranslateFunction;
        currentLanguage: string;
    }
    userFetchBegin: () => Action;
    setActiveLanguage: (languageCode: string) => SetActiveLanguageAction;
}

const Logo: React.StatelessComponent<{}> = () => {
    return (
        <div className="logo">
            LOGO
        </div>
    );
};

export const Header: React.StatelessComponent<HeaderProps> = props => {

    const { userInfo,setActiveLanguage, userFetchBegin } = props;

    console.log("HeaderHeaderHeaderHeaderHeaderHeaderHeaderHeader", props);

    return (
        <div className="header">
            <div className="header-left">
                <Logo />
                <UserInfo {...userInfo} fetchBegin={userFetchBegin} setActiveLanguage={setActiveLanguage} />
                <LinkButton className="ic-mail" newTab={true} url="/mail" />
            </div>
            <div className="header-center">
                <SearchBox />
            </div>
            <div className="header-right">
                <LinkButton className="ic-notice" newTab={true} url="/notice" />
                <LinkButton className="ic-customize" newTab={true} url="/customize" />
                <LinkButton className="ic-calendar" newTab={true} url="/calendar" />
            </div>
        </div>
    );
};

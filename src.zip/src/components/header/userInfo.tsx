import * as React from 'react';
import { Action } from '../../actions';
import { Translate, SetActiveLanguageAction, TranslateFunction, getActiveLanguage } from 'react-localize-redux';

export interface UserInfoProps {
    companyName: string;
    userName: string;
    fetchBegin: () => Action;
    setActiveLanguage: (languageCode: string) => SetActiveLanguageAction;
    translate: TranslateFunction;
    currentLanguage: string;
}

export const UserInfo: React.StatelessComponent<UserInfoProps> = (props: UserInfoProps) => {

    const { companyName, userName, fetchBegin, setActiveLanguage, translate } = props;
    const changeLanguage = () => {
        const codes = ['en', 'ja', 'zh'];
        const next = (codes.indexOf(props.currentLanguage) + 1 ) % 3;
        setActiveLanguage(codes[next]);
    }
    return (
        <div className="user-info">

            <p className="company-name">{companyName || "Porters"}</p>
            <p className="user-name">{userName || "Tanaka"}</p>
            <button onClick={fetchBegin}>Refresh</button>
            <button onClick={changeLanguage}>{translate("top.greeting")}</button>
        </div>
    );
};
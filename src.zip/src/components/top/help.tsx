import * as React from 'react';

export const Help: React.StatelessComponent<{}> = () => {
    return (
        <section className="help">
            Help Section
        </section>
    );
};

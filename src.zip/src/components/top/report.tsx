import * as React from 'react';

export const Report: React.StatelessComponent<{}> = () => {
    return (
        <section className="report">
            Report Section
        </section>
    );
};

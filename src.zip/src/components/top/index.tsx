import * as React from 'react';
import { Translate } from 'react-localize-redux';
import { Header } from '../../containers/header';
import { Footer } from '../footer';
import { OriginalSearch } from '../../containers/top';
import { Dashboard } from './dashboard';
import { Report } from './report';
import { MediaLinkage } from './mediaLinkage';
import { Help } from './help';


export const TopPage: React.StatelessComponent<{}> = () => {
    return (
        <div className="top-wrapper">
            <Header />

            <div className="main-content">
                <Translate id="top.greeting"></Translate>
                <OriginalSearch />
                <Dashboard />
                <Report />

                <MediaLinkage />
                <Help />
            </div>
            <Footer />
        </div>
    );
};

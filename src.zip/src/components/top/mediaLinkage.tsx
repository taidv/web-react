import * as React from 'react';

export const MediaLinkage: React.StatelessComponent<{}> = () => {
    return (
        <section className="media-linkage">
            Media Linkage Section
        </section>
    );
};

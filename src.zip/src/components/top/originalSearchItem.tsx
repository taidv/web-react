import * as React from 'react';

export interface OriginalSearchItemProps {
    id: number;
    title: string;
    category: string;
    url: string;
}

export const OriginalSearchItem: React.StatelessComponent<OriginalSearchItemProps> = (props: OriginalSearchItemProps) => {

    const {id, title, category, url} = props;

    //console.log(props);

    return (
        <div className="original-search-item">
            <a href={url} target='_blank'>{id} - {category} - {title}</a>
        </div>
    );
};

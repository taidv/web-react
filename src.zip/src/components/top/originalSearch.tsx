import * as React from 'react';
import { OriginalSearchItemProps, OriginalSearchItem } from './originalSearchItem';
import { Action } from '../../actions';

export interface OriginalSearchesProps {
    items: OriginalSearchItemProps[];
    fetchBegin: () => Action;
}

export const OriginalSearch: React.StatelessComponent<OriginalSearchesProps> = (props: OriginalSearchesProps) => {
    const { items, fetchBegin } = props;

    //items.map(item => console.log(item));

    return (
        <section className="original-search">
            { items &&
                items.map(item => <OriginalSearchItem id={item.id} title={item.title} category={item.category} url={item.url} />
                )
            }
            <button onClick={fetchBegin}>Refresh</button>
        </section>
    );
};

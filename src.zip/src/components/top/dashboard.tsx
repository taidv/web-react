import * as React from 'react';

export const Dashboard: React.StatelessComponent<{}> = () => {
    return (
        <section className="dashboard">
            Dashboard Section
        </section>
    );
};

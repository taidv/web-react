import { call, put } from 'redux-saga/effects';
import { loadUser as getUser } from './apiCalls';
import { Actions } from '../actions';
import { userInfo as userActions } from '../actions/userActions';

export function* loadUser() {
    try {

        console.log("SAGA: init ser: ");
        const user = yield call(getUser);
        console.log("SAGA: loadUser: ", user);
        yield put(userActions.fetchSuccess(user));

    } catch (error) {
        yield put(userActions.fetchFailure(error));
    }
}

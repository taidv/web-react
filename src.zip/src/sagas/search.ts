import { call, put } from 'redux-saga/effects';
import { loadSavedSearchConditions as getSavedSearchConditions } from './apiCalls';
import { Actions } from '../actions';
import { savedSearchConditions as searchActions } from '../actions/searchActions';

export function* loadSavedSearchConditions() {
    try {

        const _savedSearchConditions = yield call(getSavedSearchConditions);
        yield put(searchActions.fetchSuccess(_savedSearchConditions));

    } catch (error) {
        yield put(searchActions.fetchFailure(error));
    }
}

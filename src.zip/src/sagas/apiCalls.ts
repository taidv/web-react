import { SearchApi, UserApi } from '../api'

export const loadUser = () => {
    console.log('loading user...');
    return UserApi.getUser().then(res => res);
}

export const loadSavedSearchConditions = () => {
    console.log('loading original searches...');
    return SearchApi.getSavedSearchConditions().then(res => res);
}

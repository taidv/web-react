import { takeEvery, takeLatest, fork, put } from 'redux-saga/effects';
import { loadSavedSearchConditions } from './search';
import { loadUser } from './user';
import { Actions } from '../actions';

function* rootSaga() {
    yield [

        // init load
        fork(loadUser),
        fork(loadSavedSearchConditions),

        // watchers
        takeEvery(Actions.USER.FETCH_BEGIN, loadUser),
        takeLatest(Actions.SAVED_SEARCH_CONDITIONS.FETCH_BEGIN, loadSavedSearchConditions)
    ];
}

export default rootSaga;

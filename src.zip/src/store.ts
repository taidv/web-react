import { createStore, compose, applyMiddleware } from 'redux';
import rootReducer, { State } from './reducers/index';
import createSagaMiddleware from 'redux-saga';
import rootSaga from './sagas';
import { initialize, addTranslationForLanguage } from 'react-localize-redux';

const sagaMiddleware = createSagaMiddleware();
const languages = ['en', 'ja', 'zh'];

export default function configureStore() {

    const store = createStore<State>(rootReducer, compose (
        applyMiddleware(sagaMiddleware))
    );

    sagaMiddleware.run(rootSaga);

    store.dispatch(initialize(languages, { defaultLanguage: 'ja' }));
    const en = require('./translations/en.json');
    const ja = require('./translations/ja.json');
    const zh = require('./translations/zh.json');
    store.dispatch(addTranslationForLanguage(en, 'en'))
    store.dispatch(addTranslationForLanguage(ja, 'ja'))
    store.dispatch(addTranslationForLanguage(zh, 'zh'))

    return store;
}

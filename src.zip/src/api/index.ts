var _user = require('./user.json');
var _savedSearchConditions = require('./savedSearchConditions.json');

const TIMEOUT = 800;

class SearchApi {

    static getUser() {
        console.log('getting user....');
        return new Promise((resolve) => {
            setTimeout(() => {
                console.log('return user');
                resolve(_user);
            }, TIMEOUT);
        });
    }

    static getSavedSearchConditions() {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve(_savedSearchConditions);
            }, TIMEOUT * 3);
        });
    }
}

class UserApi {

    static getUser() {
        console.log('getting user....');
        return new Promise((resolve) => {
            setTimeout(() => {
                console.log('return user');
                resolve(_user);
            }, TIMEOUT);
        });
    }
}

export {
    SearchApi,
    UserApi
}

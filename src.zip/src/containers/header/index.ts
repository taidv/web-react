import { connect, Dispatch } from 'react-redux';
import { setActiveLanguage, getActiveLanguage, getTranslate } from 'react-localize-redux';
import { userInfo as UserActions } from '../../actions';
import { State } from '../../reducers';
import { Header } from '../../components/header/index';

const mapStateToProps = (state: State) => {
    const user = state.user || {};

    console.log('mapStateToPropsmapStateToProps', user);

    return {
        userInfo: {
            companyName: user.companyName,
            userName: user.userName,
            translate: getTranslate(state.locale),
            currentLanguage: getActiveLanguage(state.locale).code
        }
    };
};

const mapDispatchToProps = {
    userFetchBegin: UserActions.fetchBegin,
    setActiveLanguage
};

const SmartHeader = connect(mapStateToProps, mapDispatchToProps)(Header);

export {
    SmartHeader as Header
}
import { connect, Dispatch } from 'react-redux';
import { savedSearchConditions } from '../../actions/searchActions';
import { State } from '../../reducers';
import { OriginalSearch } from '../../components/top/originalSearch';

const mapStateToProps = (state: State) => {
    //console.log(state);
    const items = state.search.savedSearchConditions || [];
    return {
        items: items
    };
};

const fetchBegin = savedSearchConditions.fetchBegin;

const mapDispatchToProps = {
    fetchBegin
};

export default connect(mapStateToProps, mapDispatchToProps)(OriginalSearch);

import { default as OriginalSearch } from "./originalSearch";

export {
    OriginalSearch
}
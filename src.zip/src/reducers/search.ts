import { Action, Actions } from '../actions';

type SearchItem = {
    id: number;
    title: string;
    category: string;
    url: string;
}

export type State = {
    savedSearchConditions?: SearchItem[]
};

const search = (state: State = {}, action: Action): State => {

    let payload = action.payload;
    //console.log(state, action);
    switch (action.type) {
        case Actions.SAVED_SEARCH_CONDITIONS.FETCH_SUCCESS:
            return Object.assign({}, state, { savedSearchConditions: payload.items });;
        case Actions.SAVED_SEARCH_CONDITIONS.FETCH_BEGIN:
            return Object.assign({}, state, { savedSearchConditions: [] });
        default:
            return Object.assign({}, state);
    }
};

export default search;

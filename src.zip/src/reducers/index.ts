import { combineReducers } from 'redux';
import user, { State as UserState } from './user';
import search, { State as SavedSearchConditionsState } from './search';
import { localeReducer as locale, LocaleState } from 'react-localize-redux';

export interface State {
    user: UserState;
    search: SavedSearchConditionsState,
    locale: LocaleState
}

const rootReducer = combineReducers<State>({
    user,
    search,
    locale
});

export default rootReducer;
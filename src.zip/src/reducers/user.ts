import { Action, Actions } from '../actions';

export type State = {
    companyName?: string,
    userName?: string
};

const fetchSucess = (state: State, companyName: string, userName: string): State => {
    return Object.assign({}, state, {companyName, userName});
}

const fetchBegin = (state: State): State => {
    return Object.assign({}, state, {companyName: undefined, userName: undefined});
}

const defaultState = (state: State): State => {
    return Object.assign({}, state);
}

const user = (state: State = {}, action: Action): State => {

    let payload = action.payload;
    console.log(state, action);
    switch (action.type) {
        case Actions.USER.FETCH_SUCCESS:
            return fetchSucess(state, payload.user.companyName, payload.user.userName);
        case Actions.USER.FETCH_BEGIN:
            return fetchBegin(state);
        default:
            return defaultState(state);
    }
};

export default user;
import * as React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import { createStore, Store } from 'redux';
import { TopPage } from './components/top';
import configureStore from './store';

import './static/main.css';

const store = configureStore();

render(
    <Provider store={store}>
        <Router>
            <Route path="/" component={TopPage}/>
        </Router>
    </Provider>,
    document.getElementById('main')
);

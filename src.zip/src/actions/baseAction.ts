
// interface BaseAction<T, P> {
//     type: T;
//     payload?: P;
// }

// type LoadUserSuccessPayload = {
//     user: any
// };

// type LoadUserFailurePayload = {
//     error: any
// };

// type Action = BaseAction<
//   string,
//   | LoadUserSuccessPayload
//   | LoadUserFailurePayload
// >;

type Action = {
    type: string;
    meta?: any;
    payload: any;
    error?: boolean;
};

export {
    Action
}
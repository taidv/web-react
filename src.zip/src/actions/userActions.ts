import { Actions } from './actionTypes';
import { Action } from './baseAction';

export const userInfo = {

    fetchBegin: (): Action => ({
        type: Actions.USER.FETCH_BEGIN,
        payload: {}
    }),

    fetchSuccess: (user: any): Action => ({
        type: Actions.USER.FETCH_SUCCESS,
        payload: {
            user: user
        }
    }),

    fetchFailure: (error: any): Action => ({
        type: Actions.USER.FETCH_FAILURE,
        payload: {
            error: error
        }
    })
}

import { Actions } from './actionTypes';
import { Action } from './baseAction';

export const savedSearchConditions = {
    fetchBegin: (): Action => ({
        type: Actions.SAVED_SEARCH_CONDITIONS.FETCH_BEGIN,
        payload: {}
    }),

    fetchSuccess: (items: any): Action => ({
        type: Actions.SAVED_SEARCH_CONDITIONS.FETCH_SUCCESS,
        payload: {
            items: items
        }
    }),

    fetchFailure: (error: any): Action => ({
        type: Actions.SAVED_SEARCH_CONDITIONS.FETCH_FAILURE,
        payload: {
            error: error
        }
    }),

}